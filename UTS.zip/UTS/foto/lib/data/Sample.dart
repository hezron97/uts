import 'package:flutter_photography/models/Collocation.dart';
import 'package:flutter_photography/models/Post.dart';
import 'package:flutter_photography/models/User.dart';

class Sample {
  static User hezron = new User(
    name: "Hezron Hezekiah Lesmana",
    username: "@hezronhezekiahlesmana",
    followers: 1000,
    following: 200,
    profilePicture: "assets/users/hezron.jpg",
    collocation: [
      new Collocation(
        name: "Photography",
        tags: [
          "HD Photos",
          "Nature",
          "Photography"
        ],
        thumbnail: "assets/photos/one.jpg",
        posts: [
          new Post(
            location: "Jakarta, Indonesia",
            dateAgo: "1 min ago",
            photos: [
              'assets/photos/one.jpg',
              'assets/photos/two.jpg',
              'assets/photos/three.jpg',
            ]
          ),
          new Post(
            location: "Jakarta, Indonesia",
            dateAgo: "2 week ago",
            photos: [
              'assets/photos/six.jpg',
              'assets/photos/eight.jpg',
              'assets/photos/two.jpg',
            ]
          )
        ]
      ),
      new Collocation(
        name: "Photography",
        tags: [
          "HD Photos",
          "Nature",
          "Photography"
        ],
        thumbnail: "assets/photos/five.jpg",
        posts: [
          new Post(
            location: "Jakarta, Indonesia",
            dateAgo: "3 min ago",
            photos: [
              'assets/photos/one.jpg',
              'assets/photos/two.jpg',
              'assets/photos/three.jpg',
            ]
          ),
          new Post(
            location: "Jakarta, Indonesia",
            dateAgo: "2 week ago",
            photos: [
              'assets/photos/six.jpg',
              'assets/photos/eight.jpg',
              'assets/photos/two.jpg',
            ]
          )
        ]
      ),
    ]
  );

  static User hz = new User(
    name: "hzphotovideoeditorgraphy",
    username: "@hzphotovideoeditorgraphy",
    followers: 2000,
    following: 190,
    profilePicture: "assets/users/hz.jpg",
    collocation: [
      new Collocation(
        name: "Photography",
        tags: [
          "HD Photos",
          "Nature",
          "Photography"
        ],
        thumbnail: "assets/photos/two.jpg",
        posts: [
          new Post(
            location: "Jakarta, Indonesia",
            dateAgo: "3 min ago",
            photos: [
              'assets/photos/five.jpg',
              'assets/photos/six.jpg',
              'assets/photos/seven.jpg',
            ]
          ),
          new Post(
            location: "Jakarta, Indonesia",
            dateAgo: "2 week ago",
            photos: [
              'assets/photos/six.jpg',
              'assets/photos/eight.jpg',
              'assets/photos/two.jpg',
            ]
          )
        ]
      ),
    ]
  );

  static Post postOne = new Post(
    user: hezron,
    location: "Jakarta, Indonesia",
    dateAgo: "3 min ago",
    photos: [
      'assets/photos/one.jpg',
      'assets/photos/two.jpg',
      'assets/photos/three.jpg'
    ],
    relatedPhotos: [
      'assets/photos/four.jpg',
      'assets/photos/five.jpg',
      'assets/photos/six.jpg',
      'assets/photos/seven.jpg',
      'assets/photos/eight.jpg'
    ]
  );

  static Post postTwo = new Post(
     user: hz,
    location: "Jakarta, Indonesia",
    dateAgo: "3 min ago",
    photos: [
      'assets/photos/four.jpg',
      'assets/photos/five.jpg',
      'assets/photos/six.jpg',
    ],
    relatedPhotos: [
      'assets/photos/one.jpg',
      'assets/photos/two.jpg',
      'assets/photos/three.jpg',
      'assets/photos/four.jpg',
      'assets/photos/five.jpg'
    ]
  );
}