package com.example.flutter_photography

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
